package com.scor.polka.polkaGeteway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@PropertySource("classpath:application.properties")
@Configuration
public class PolkaGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolkaGatewayApplication.class, args);
	}

}
