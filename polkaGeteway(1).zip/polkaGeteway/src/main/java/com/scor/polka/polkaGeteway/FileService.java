package com.scor.polka.polkaGeteway;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class FileService {

	@Value("${file.upload.repository}")
	private String repository;

	public String saveFile(byte[] fileContent, String fileName) {
		File repo = new File(repository);
		if (!repo.exists()) {
			repo.mkdirs();
		}
		OutputStream outputStream = null;
		try {
			String pathname = repository + File.separator + fileName;
			File file = new File(pathname);
			outputStream = new FileOutputStream(file);
			outputStream.write(fileContent);
			return pathname;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

}
