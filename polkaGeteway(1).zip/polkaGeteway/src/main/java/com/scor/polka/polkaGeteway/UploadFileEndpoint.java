package com.scor.polka.polkaGeteway;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.scor.polka.entities.UploadFileMetadata;
import com.scor.polka.entities.UploadFileMetadataResponse;

@Endpoint
public class UploadFileEndpoint {
	private static final String NAMESPACE_URI = "http://scor.com/polka/entities/";

	private FileService fileService;
	private RestTemplate restTemplate;

	@Autowired
	public UploadFileEndpoint(FileService fileService, RestTemplate restTemplate) {
		this.fileService = fileService;
		this.restTemplate = restTemplate;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "uploadFileMetadata")
	@ResponsePayload
	public UploadFileMetadataResponse uploadFile(@RequestPayload UploadFileMetadata request) {
		UploadFileMetadataResponse response = new UploadFileMetadataResponse();
		String pathname = fileService.saveFile(request.getFile(), request.getFileinfo().getMetadata().getName());
		if (StringUtils.isBlank(pathname)) {
			response.setStatus("KO");
			return response;
		}
		boolean isConsumed = airflowConsume(request, pathname);
		if (!isConsumed) {
			response.setStatus("KO");
			return response;
		}
		response.setStatus("OK");
		return response;
	}

	private boolean airflowConsume(UploadFileMetadata request, String pathname) {
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		AirflowRequest airflowRequest = new AirflowRequest(request, pathname);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(airflowRequest, header);
		ResponseEntity<String> response = restTemplate.exchange(
				"http://localhost:8080/api/experimental/dags/get_response_polka/dag_runs", HttpMethod.POST,
				requestEntity, String.class);
		return true;
	}
}