package com.scor.polka.polkaGeteway;

import java.io.Serializable;

import javax.xml.datatype.XMLGregorianCalendar;

import com.scor.polka.entities.UploadFileMetadata;
import com.scor.polka.entities.UploadFileMetadata.Fileinfo;
import com.scor.polka.entities.UploadFileMetadata.Fileinfo.Metadata;

public class AirflowRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5459260584422599277L;

	private String coreId;
	private String company;
	private String country;
	private int year;
	private int month;
	private String pathFile;

	public AirflowRequest() {
		super();
	}

	public AirflowRequest(UploadFileMetadata uploadFileMetadata, String pathname) {
		Fileinfo fileinfo = uploadFileMetadata.getFileinfo();
		if (fileinfo != null) {
			this.coreId = fileinfo.getCoreid();
			Metadata metadata = fileinfo.getMetadata();
			if (metadata != null) {
				this.company = metadata.getCompany();
				this.country = metadata.getCountry();
				XMLGregorianCalendar date = metadata.getDate();
				if (date != null) {
					this.month = date.getMonth();
					this.year = date.getYear();
				}
			}
		}
		this.pathFile = pathname;
	}

	public String getCoreId() {
		return coreId;
	}

	public void setCoreId(String coreId) {
		this.coreId = coreId;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getPathFile() {
		return pathFile;
	}

	public void setPathFile(String pathFile) {
		this.pathFile = pathFile;
	}
	
	

}
